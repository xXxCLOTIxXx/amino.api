<h1 align="center">Amino.API</h1>
<h2 align="center">Unofficial library to interact with Aminoapps.</h2>

Developers:
- Xsarz: https://linktr.ee/xsarz
- imperialwool: https://linktr.ee/imperialwool