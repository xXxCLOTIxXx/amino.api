


class AsyncLocalClient:
	def __init__(self):
		pass