
class AsyncSocket:
	def __init__(self):
		pass