
class AsyncClient:
	def __init__(self):
		pass