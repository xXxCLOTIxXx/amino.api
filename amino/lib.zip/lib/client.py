from .utils.generator import Generator
from .utils import exceptions, objects
from .socket import AsyncSocket, AsyncCallBacks

from asyncio import get_event_loop, new_event_loop, sleep, create_task
from requests import Session
from json import loads, dumps
from time import time as timestamp

from typing import BinaryIO
from base64 import b64encode
from random import randint

gen = Generator()

class Client(AsyncSocket, AsyncCallBacks):
	def __init__(self, deviceId: str=None, sock_debug: bool = False, socket_enabled: bool = True, comId: int = None):
		self.api = "https://service.aminoapps.com/api/v1"
		self.sock_debug = sock_debug
		self.socket_enabled = socket_enabled
		self.deviceId = deviceId if deviceId else gen.generateDeviceId()
		self.comId = comId
		self.sid = None
		self.profile = objects.UserProfile

		self.session = Session()

		AsyncSocket.__init__(self, generator=gen, client=self)
		AsyncCallBacks.__init__(self)



	def headers(self, data = None, content_type = None):

		h = {
			"NDCDEVICEID": self.deviceId,
			"NDCLANG": "ru",
			"Accept-Language": "ru-RU",
			"SMDEVICEID": "20230109055041eecd2b9dd8439235afe4522cb5dacd26011dba6bbfeeb752", 
			"User-Agent": "Apple iPhone12,1 iOS v15.5 Main/3.12.2",
			"Content-Type": "application/json; charset=utf-8",
			"Host": "service.narvii.com",
			"Accept-Encoding": "gzip",
			"Connection": "Upgrade"
			}


		if data is not None:
			h["Content-Length"] = str(len(data))
			h["NDC-MSG-SIG"] = gen.signature(data=data)

		if self.sid:h["NDCAUTH"] = f"sid={self.sid}"
		if content_type:h["Content-Type"] = content_type
		return h

	async def _online_loop(self):
		while True:
			data =  {
				"t": 304,
				"o": {"actions": ["Browsing"], "target":f"ndc://x{self.comId}/", "ndcId":self.comId,'id': str(randint(1, 1000000))},
			}
			try:
				await self.send(data)
			except Exception as e:
				if self.sock_debug:
					print('[socket][_online_loop][error] ', e)
			await sleep(self.pingTime)


	async def Online(self):
		if self.online_loop_active:return
		self.online_loop_active = create_task(self._online_loop())
		return self.online_loop_active

	async def Offline(self):
		if self.online_loop_active:
			self.online_loop_active.cancel()
			self.online_loop_active = None
		return self.online_loop_active



	async def login(self, email: str, password: str):

		data = dumps({
			"email": email,
			"v": 2,
			"secret": f"0 {password}",
			"deviceID": self.deviceId,
			"clientType": 100,
			"action": "normal",
			"timestamp": int(timestamp() * 1000)
		})

		response = self.session.post(f"{self.api}/g/s/auth/login", headers=self.headers(data=data), data=data)
		if response.status_code != 200: return exceptions.CheckException(response.text)
		else:
			data = loads(response.text)
			self.sid = data["sid"]
			self.profile = objects.UserProfile(data.get("account", {})).UserProfile
			if self.socket_enabled:await self.connect()
			return response.status_code


	async def logout(self):

		data = dumps({
			"deviceID": self.deviceId,
			"clientType": 100,
			"timestamp": int(timestamp() * 1000)
		})
		if self.socket_enabled and self.active:await self.disconnect()
		response=self.session.post(f"{self.api}/g/s/auth/logout", headers=self.headers(data=data), data=data)
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code


	async def get_from_link(self, link: str):

		response = self.session.get(f"{self.api}/g/s/link-resolution?q={link}", headers=self.headers())
		return exceptions.CheckException(response.text) if response.status_code != 200 else objects.FromCode(loads(response.text)["linkInfoV2"]).FromCode


	async def ban(self, userId: str, reason: str, banType: int = None):
		data = dumps({
			"reasonType": banType,
			"note": {
				"content": reason
			},
			"timestamp": int(timestamp() * 1000)
		})


		response = self.session.post(f"{self.api}/x{self.comId}/s/user-profile/{userId}/ban", headers=self.headers(data=data), data=data)
		return exceptions.CheckException(await response.text()) if response.status_code != 200 else response.status_code



	async def send_message(self, chatId: str, message: str = None, messageType: int = 0, file: BinaryIO = None, fileType: str = None, replyTo: str = None, mentionUserIds: list = None, stickerId: str = None, embedId: str = None, embedType: int = None, embedLink: str = None, embedTitle: str = None, embedContent: str = None, embedImage: BinaryIO = None, linkSnippet: str = None, linkSnippetImage: BinaryIO = None):
		if message is not None and file is None:
			message = message.replace("<@", "‎‏").replace("@>", "‬‭")

		mentions = []
		if mentionUserIds:
			for mention_uid in mentionUserIds:
				mentions.append({"uid": mention_uid})

		if embedImage:
			embedImage = [[100, self.upload_media(embedImage, "image"), None]]

		if linkSnippetImage:
			linkSnippetImage = base64.b64encode(linkSnippetImage.read()).decode()

		data = {
			"type": messageType,
			"content": message,
			"clientRefId": int(timestamp() / 10 % 1000000000),
			"attachedObject": {
				"objectId": embedId,
				"objectType": embedType,
				"link": embedLink,
				"title": embedTitle,
				"content": embedContent,
				"mediaList": embedImage
			},
			"extensions": {
				"mentionedArray": mentions,
				"linkSnippetList": [{
					"link": linkSnippet,
					"mediaType": 100,
					"mediaUploadValue": linkSnippetImage,
					"mediaUploadValueContentType": "image/png"
				}]
			},
			"timestamp": int(timestamp() * 1000)
		}

		if replyTo: data["replyMessageId"] = replyTo

		if stickerId:
			data["content"] = None
			data["stickerId"] = stickerId
			data["type"] = 3

		if file:
			data["content"] = None
			if fileType == "audio":
				data["type"] = 2
				data["mediaType"] = 110

			elif fileType == "image":
				data["mediaType"] = 100
				data["mediaUploadValueContentType"] = "image/jpg"
				data["mediaUhqEnabled"] = True

			elif fileType == "gif":
				data["mediaType"] = 100
				data["mediaUploadValueContentType"] = "image/gif"
				data["mediaUhqEnabled"] = True

			else: raise exceptions.WrongType(fileType)

			data["mediaUploadValue"] = base64.b64encode(file.read()).decode()

		data = dumps(data)

		response=self.session.post(f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/message", headers=self.headers(data=data), data=data)
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code


	async def get_recent_blogs(self, pageToken: str = None, start: int = 0, size: int = 25):
		if pageToken: url = f"{self.api}/x{self.comId}/s/feed/blog-all?pagingType=t&pageToken={pageToken}&size={size}"
		else: url = f"{self.api}/x{self.comId}/s/feed/blog-all?pagingType=t&start={start}&size={size}"

		response = self.session.get(url, headers=self.headers())
		return exceptions.CheckException(response.text) if response.status_code != 200 else objects.RecentBlogs(loads(response.text)).RecentBlogs.json


	async def edit_community(self, name: str = None, description: str = None, aminoId: str = None, primaryLanguage: str = None, themePackUrl: str = None, joinType: int = None):

		"""
		
		joinType: int 
			0 - open
			1 - permission needed
			2 - closed

		"""

		data = {"timestamp": int(timestamp() * 1000)}

		if name: data["name"] = name
		if description: data["content"] = description
		if aminoId: data["endpoint"] = aminoId
		if primaryLanguage: data["primaryLanguage"] = primaryLanguage
		if themePackUrl: data["themePackUrl"] = themePackUrl
		if joinType: data["joinType"] = joinType

		data = dumps(data)

		response=self.session.post(f"{self.api}/x{self.comId}/s/community/settings", headers=self.headers(data=data), data=data)
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code


	async def get_users(self, type: str = "recent", start: int = 0, size: int = 25):

		if type == "recent": url = f"{self.api}/x{self.comId}/s/user-profile?type=recent&start={start}&size={size}"
		elif type == "banned": url = f"{self.api}/x{self.comId}/s/user-profile?type=banned&start={start}&size={size}"
		elif type == "featured": url = f"{self.api}/x{self.comId}/s/user-profile?type=featured&start={start}&size={size}"
		elif type == "leaders": url = f"{self.api}/x{self.comId}/s/user-profile?type=leaders&start={start}&size={size}"
		elif type == "curators": url = f"{self.api}/x{self.comId}/s/user-profile?type=curators&start={start}&size={size}"
		else: raise exceptions.WrongType(type)

		response=self.session.get(url, headers=self.headers())
		return exceptions.CheckException(response.text) if response.status_code != 200 else objects.UserProfileCountList(loads(response.text)).UserProfileCountList


	async def comment(self, message: str, userId: str):
		data = dumps({
			"content": message,
			"stickerId": None,
			"type": 0,
			"timestamp": int(timestamp() * 1000),
			"eventSource": "UserProfileView"
		})


		response=self.session.post(f"{self.api}/x{self.comId}/s/user-profile/{userId}/comment", headers=self.headers(data=data), data=data)
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code



	async def join_chat(self, chatId: str):
		data = dumps({"timestamp": int(timestamp() * 1000)})

		response = self.session.post(f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/member/{self.profile.userId}", headers=self.headers(data=data), data=data)
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code


	async def leave_chat(self, chatId: str):

		response= self.session.delete(f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/member/{self.profile.userId}", headers=self.headers())
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code




	async def kick(self, userId: str, chatId: str, allowRejoin: bool = True):
		if allowRejoin: allowRejoin = 1
		if not allowRejoin: allowRejoin = 0

		response=self.session.delete(f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/member/{userId}?allowRejoin={allowRejoin}", headers=self.headers())
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code



	async def delete_message(self, chatId: str, messageId: str, asStaff: bool = False, reason: str = None):

		data = {
			"adminOpName": 102,
			"timestamp": int(timestamp() * 1000)
		}
		if asStaff and reason:data["adminOpNote"] = {"content": reason}

		data = dumps(data)

		if asStaff:
			response=self.session.post(f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/message/{messageId}/admin", headers=self.headers(data=data), data=data)
			return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code

		response=self.session.delete(f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/message/{messageId}", headers=self.headers(data=data))
		return exceptions.CheckException(response.text) if response.status_code != 200 else response.status_code


	async def get_chat_messages(self, chatId: str, size: int = 25, pageToken: str = None):

		if pageToken is not None: url = f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/message?v=2&pagingType=t&pageToken={pageToken}&size={size}"
		else: url = f"{self.api}/x{self.comId}/s/chat/thread/{chatId}/message?v=2&pagingType=t&size={size}"

		response=self.session.get(url, headers=self.headers())
		return exceptions.CheckException(response.text) if response.status_code != 200 else objects.GetMessages(loads(response.text)).GetMessages