from aiohttp import ClientSession, WSMsgType
from .utils import objects
from asyncio import create_task, sleep, exceptions
from json import dumps, loads
from time import time

from asyncio import get_event_loop
from traceback import format_exc
from sys import _getframe as getframe

class AsyncSocket:
	def __init__(self, generator, client):
		self.socket_url = "wss://ws1.aminoapps.com"
		self.client = client
		self.debug=self.client.sock_debug

		self.task_resolve = None
		self.socket = None
		self.connection = None
		self.active = True

		self.online_loop_active = None
		self.generator = generator

		self.pingTime = 10
		self.reconnect_time = 40
		self.reconnect_task = None


	async def resolve(self):
		while True:
			try:
				msg = await self.connection.receive()
				if msg.type != WSMsgType.TEXT: continue
				data = loads(msg.data)
				try:
					if data["o"]["ndcId"] != self.client.comId:continue
				except KeyError:continue
				if data["t"] == 1000:
					await self.on_resolve(data)
					await self.methods.get(f"{data['o']['chatMessage']['type']}:{data['o']['chatMessage'].get('mediaType', 0)}", self.default)(data)
			except exceptions.CancelledError:
				break
			except:
				print(format_exc())



	async def connect(self):
		try:
			if self.debug:
				print(f"[socket][start] Starting Socket")
			self.socket = ClientSession(base_url=self.socket_url)

			endpoint = f"{self.client.deviceId}|{int(time() * 1000)}"
			headers = {"NDCDEVICEID": self.client.deviceId,"NDCAUTH": f"sid={self.client.sid}","NDC-MSG-SIG": self.generator.signature(endpoint)}
			self.connection = await self.socket.ws_connect(f"/?signbody={endpoint.replace('|', '%7C')}", headers=headers)
			self.task_resolve = create_task(self.resolve())
			if self.reconnect_task is None:self.reconnect_task = create_task(self.reconnect())
			self.active = True
			if self.debug:
				print(f"[socket][start] Socket Started")
		except:
			if self.debug:
				print(f"[socket][start] Error while starting Socket : {format_exc()}")


	async def disconnect(self):
		if self.debug:
			print(f"[socket][close] Closing Socket")
		try:
			if self.task_resolve: self.task_resolve.cancel()
			if self.online_loop_active:
				self.online_loop_active.cancel()
				self.online_loop_active = None
			if self.connection:
				await self.connection.close()
				self.connection = None
			if self.socket:
				await self.socket.close()
				self.socket = None
			self.active = False
			if self.debug:
				print(f"[socket][close] Socket closed")
		except Exception as e:
			if self.debug:
				print(f"[socket][close] Error while closing Socket : {e}")



	async def reconnect(self):
		while True:
			try:
				await sleep(self.reconnect_time)
				if self.active:
					loop = self.online_loop_active
					if self.debug:print(f"[socket][reconnect] Reconnecting Socket")
					await self.disconnect()
					await self.connect()
					if loop:
						await self.Online()
					del loop
				else:
					self.reconnect_task.cancel()
			except Exception as e:
				if self.debug:
					print(f"[socket][reconnect] Error: {e}")


	async def send(self, data: dict):
		if self.debug:print(f"[socket][send] Sending Data : {data}")
		await self.connection.send_str(dumps(data))


class AsyncCallBacks:
	def __init__(self):
		self.handlers = {}

		self.methods = {
			"0:0": self.on_text_message,
			"0:100": self.on_image_message,
			"0:103": self.on_youtube_message,
			"1:0": self.on_strike_message,
			"2:110": self.on_voice_message,
			"3:113": self.on_sticker_message,
			"52:0": self.on_voice_chat_not_answered,
			"53:0": self.on_voice_chat_not_cancelled,
			"54:0": self.on_voice_chat_not_declined,
			"55:0": self.on_video_chat_not_answered,
			"56:0": self.on_video_chat_not_cancelled,
			"57:0": self.on_video_chat_not_declined,
			"58:0": self.on_avatar_chat_not_answered,
			"59:0": self.on_avatar_chat_not_cancelled,
			"60:0": self.on_avatar_chat_not_declined,
			"100:0": self.on_delete_message,
			"101:0": self.on_group_member_join,
			"102:0": self.on_group_member_leave,
			"103:0": self.on_chat_invite,
			"104:0": self.on_chat_background_changed,
			"105:0": self.on_chat_title_changed,
			"106:0": self.on_chat_icon_changed,
			"107:0": self.on_voice_chat_start,
			"108:0": self.on_video_chat_start,
			"109:0": self.on_avatar_chat_start,
			"110:0": self.on_voice_chat_end,
			"111:0": self.on_video_chat_end,
			"112:0": self.on_avatar_chat_end,
			"113:0": self.on_chat_content_changed,
			"114:0": self.on_screen_room_start,
			"115:0": self.on_screen_room_end,
			"116:0": self.on_chat_host_transfered,
			"117:0": self.on_text_message_force_removed,
			"118:0": self.on_chat_removed_message,
			"119:0": self.on_text_message_removed_by_admin,
			"120:0": self.on_chat_tip,
			"121:0": self.on_chat_pin_announcement,
			"122:0": self.on_voice_chat_permission_open_to_everyone,
			"123:0": self.on_voice_chat_permission_invited_and_requested,
			"124:0": self.on_voice_chat_permission_invite_only,
			"125:0": self.on_chat_view_only_enabled,
			"126:0": self.on_chat_view_only_disabled,
			"127:0": self.on_chat_unpin_announcement,
			"128:0": self.on_chat_tipping_enabled,
			"129:0": self.on_chat_tipping_disabled,
			"65281:0": self.on_timestamp_message,
			"65282:0": self.on_welcome_message,
			"65283:0": self.on_invite_message,
		}

	def event(self, type: str):
		def registerHandler(handler):
			if type in self.handlers:
				self.handlers[type].append(handler)
			else:
				self.handlers[type] = [handler]
			return handler
		return registerHandler

	async def call(self, type, data):
		if type in self.handlers:
			for handler in self.handlers[type]:
				await handler(data)

	async def on_text_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_image_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_youtube_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_strike_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_sticker_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_not_answered(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_not_cancelled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_not_declined(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_video_chat_not_answered(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_video_chat_not_cancelled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_video_chat_not_declined(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_avatar_chat_not_answered(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_avatar_chat_not_cancelled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_avatar_chat_not_declined(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_delete_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_group_member_join(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_group_member_leave(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_invite(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_background_changed(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_title_changed(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_icon_changed(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_start(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_video_chat_start(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_avatar_chat_start(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_end(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_video_chat_end(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_avatar_chat_end(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_content_changed(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_screen_room_start(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_screen_room_end(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_host_transfered(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_text_message_force_removed(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_removed_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_text_message_removed_by_admin(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_tip(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_pin_announcement(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_permission_open_to_everyone(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_permission_invited_and_requested(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_voice_chat_permission_invite_only(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_view_only_enabled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_view_only_disabled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_unpin_announcement(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_tipping_enabled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_chat_tipping_disabled(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_timestamp_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_welcome_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_invite_message(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_user_typing_start(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_user_typing_end(self, data): await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def on_resolve(self, data):await self.call(getframe(0).f_code.co_name, objects.Event(data["o"]).Event)
	async def default(self, data): await self.call(getframe(0).f_code.co_name, data)