"""
Author: Xsarz

Enjoy using!
"""

from .utils import exceptions, generator, objects
from .client import Client
from .socket import AsyncSocket

__title__ = 'AACB - Amino Async Chat Bots'
__author__ = 'Xsarz'
__license__ = 'MIT'
__copyright__ = 'Copyright 2023 Xsarz'