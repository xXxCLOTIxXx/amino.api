from .generator import Generator

class Headers:
	def __init__(self, deviceId: str = None, sid: str = None):
		self.deviceId = deviceId
		self.sid=sid
		self.deviceId = Generator().generateDeviceId()

	def iphone_headers(self, data = None, content_type = None):

		headers = {
			"NDCDEVICEID": self.deviceId,
			"NDCLANG": "ru",
			"Accept-Language": "ru-RU",
			"SMDEVICEID": "20230109055041eecd2b9dd8439235afe4522cb5dacd26011dba6bbfeeb752", 
			"User-Agent": "Apple iPhone12,1 iOS v15.5 Main/3.12.2",
			"Content-Type": "application/json; charset=utf-8",
			"Host": "service.narvii.com",
			"Accept-Encoding": "gzip",
			"Connection": "Upgrade"
			}


		if data is not None:
			headers["Content-Length"] = str(len(data))
			headers["NDC-MSG-SIG"] = Generator().signature(data=data)

		if self.sid:headers["NDCAUTH"] = f"sid={self.sid}"

		if content_type:headers["Content-Type"] = content_type

		return headers

	def android_headers(self, data = None, content_type = None):

		headers = {
			"NDCDEVICEID": self.deviceId,
			"Accept-Language": "en-US",
			"Content-Type": "application/json; charset=utf-8",
			"User-Agent": "Dalvik/2.1.0 (Linux; U; Android 7.1.2; SM-G965N Build/star2ltexx-user 7.1.; com.narvii.amino.master/3.4.33602)",
			"Host": "service.narvii.com",
			"Accept-Encoding": "gzip",
			"Connection": "Upgrade"
		}

		if data:
			headers["Content-Length"] = str(len(data))
			headers["NDC-MSG-SIG"] = Generator().signature(data=data)

		if self.sid: headers["NDCAUTH"] = f"sid={self.sid}"
		if content_type: headers["Content-Type"] = content_type


		return headers



	def iphoneWeb_headers(self):
		return None

	def web_headers(self, referer: str, content_type = None):
		headers = {
			"user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/73.0.3683.86 Chrome/73.0.3683.86 Safari/537.36",
			"content-type": "application/json",
			"x-requested-with": "xmlhttprequest",
			"cookie": f"sid={self.sid}",
			"referer": referer
		}

		if content_type: headers["content-type"] = content_type

		return headers
